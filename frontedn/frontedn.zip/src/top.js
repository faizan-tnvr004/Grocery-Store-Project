import React from "react";
import "./top.css"; // Import the CSS file

function Header() {
  return <div className="store-top">
    <img src = "logofast.png"
alt="logo"
className="store-logo"
    ></img>

<div className="store_name">HF STORE</div>

  </div>;
}

export default Header;
