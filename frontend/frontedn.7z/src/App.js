import React from "react";
import Header from "./top"; // Import the Header component
import FirstProd  from "./first_row";



function App() {
  return (
    <div>
    <Header />
      <FirstProd />
    </div>
  );
}

export default App;
